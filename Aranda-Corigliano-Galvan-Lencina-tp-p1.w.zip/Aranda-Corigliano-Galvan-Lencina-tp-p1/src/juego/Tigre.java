
	package juego;

	
	import java.awt.Image;
	
	import entorno.Entorno;
	import entorno.Herramientas;

	public class Tigre
	{
		// Variables de instancia
		private double x;
		private double y;
		private Image img2;
		

		
		
		
		public Tigre(int x, int y) 
		{
			this.x = x;
			this.y = y;
		    
			this.img2 = Herramientas.cargarImagen("Z8Dq.gif");
				
		}
		
		public void dibujarse(Entorno entorno)
		{
			//entorno.dibujarTriangulo(this.x, this.y, 50, 30, this.angulo, Color.yellow);
		
			
				entorno.dibujarImagen(this.img2, this.x, this.y, 0, 0.3);
				
			//	entorno.dibujarRectangulo(this.x, this.y, 60, 10, this.angulo, Color.yellow);
				
			
		
		}

		
		
		public double getX() {
			return x;
		}

		public void setX(double x) {
			this.x = x;
		}

		public double getY() {
			return y;
		}

		public void setY(double y) {
			this.y = y;
		}

		public void moverIzquierda(int a) {
			this.x -= Math.cos(0)*a;
			
			if(this.x > 1300) {
				this.x=-100;
			}
			if(this.x < -100) {
				this.x=1300;
			}
		}
			

		

		
	}





