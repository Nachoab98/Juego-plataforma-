package juego;

import java.awt.Color;
import java.awt.Image;
//import java.io.BufferedInputStream;
//import java.io.InputStream;
//import javax.sound.*;
//import java.awt.FlowLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import entorno.*;

public class Juego extends InterfaceJuego {
	private Entorno entorno;
	// otras variables del juego aqui
	private boolean cierra;
	private Image imgFondo;
	private Mono mono;
	private int puntos;
	private Image a = Herramientas.cargarImagen("arbol.png");
	private Image b = Herramientas.cargarImagen("arbol1.png");
	private Arbol arbol;
	private Arbol arbol1;
	private Arbol arbol2;
	private Arbol arbol3;
	private Arbol arboles[];
	private Aguila aguila;
	private Tigre tigre1;
	private Tigre tigre3;
	private boolean bajarderama;
	private Tigre tigres[];
	private double anguloFondo;
	private Piedra piedra;
	private Serpiente serpiente;
	private boolean musicafondo=true;
	private int HighScore;
	private int jugar = 0;
	private Image menu;
	private Image GameOver;
	private Image ganaste;
	private int nivel;
	private int level;
    public void ReproducirSonido(String nombreSonido, boolean cierra){
        try {
         AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(nombreSonido).getAbsoluteFile());
         Clip clip = AudioSystem.getClip();
         clip.open(audioInputStream);
         clip.start();
         if (cierra==true) {
        	 clip.close();
         }
         
        } catch(UnsupportedAudioFileException | IOException | LineUnavailableException ex) {
          System.out.println("Error al reproducir el sonido.");
        }
      
       } 
		
	

	Juego() {
		// Inicializa el objeto entorno, pero aun no lo inicia.
		cierra=false;
		entorno = new Entorno(this, "selva Mono Capuchino Nr. 4", 800, 600);
		puntos=0;
		mono = new Mono(100, 530);
		arbol = new Arbol(750, 440, a);
		arbol1 = new Arbol(1400, 440, b);
		arbol2= new Arbol(1000, 440, a);
		arbol3= new Arbol(1600, 440, b);
		this.piedra	= new Piedra(-200,mono.getY());
		Arbol arboles[] = { arbol, arbol1, arbol2, arbol3};
		this.arboles = arboles;	
		aguila=new Aguila(800,0);
		tigre1 = new Tigre(800, 530);
		serpiente= new Serpiente(arboles[(int) (Math.random() * arboles.length)].rama.getX(),arboles[(int) (Math.random() * arboles.length)].rama.getY()-(arboles[(int) (Math.random() * arboles.length)].rama.getY()*0.1));
		this.bajarderama = false;
		tigre3 = new Tigre(1300, 530);
		HighScore = 0;
		Tigre tigres[] = { tigre1,tigre3};
		this.tigres = tigres;
		mono.setPiedra(new Piedra(115, 530));
		imgFondo = Herramientas.cargarImagen("campo.png");
		anguloFondo = 0;
		nivel = 100;
		level=1;
		if (musicafondo ==true) {
		ReproducirSonido("src/music.wav/",cierra);
		}
		menu = Herramientas.cargarImagen("menu.png");
		GameOver = Herramientas.cargarImagen("game over.gif");
		ganaste= Herramientas.cargarImagen("ganaste.gif");
		/*
		 * Es fundamental que reci�n al final del constructor de la clase Juego se
		 * inicie el objeto entorno de la siguiente manera.
		 */
		 
		
		entorno.iniciar();
		
		

	}

	/*
	 * Durante el juego, el m�todo tick() ser� ejecutado en cada instante y por lo
	 * tanto es el m�todo m�s importante de esta clase. Aqu� se debe actualizar el
	 * estado interno del juego para simular el paso del tiempo (ver el enunciado
	 * del TP para mayor detalle).
	 */
	public void tick() {
		if (jugar==0) {
            entorno.dibujarImagen(menu, 400, 300, 0, 1);
            if(entorno.sePresiono(entorno.TECLA_ENTER)) {
                jugar+=1;
            }
        }

		
		if (puntos<0) {
			puntos=0;
		}
		
		if(puntos >= nivel) {
			entorno.dibujarImagen(ganaste, 400, 300, anguloFondo, 0.5);
			if(HighScore < puntos) {
				HighScore = puntos;
				}
			
			ReproducirSonido("src/win2.wav/",cierra);
			cierra=true;
			this.musicafondo=false;
			if(entorno.sePresiono(entorno.TECLA_ENTER)) {
				mono.setVidas(mono.getVidas() + 2);
				this.puntos= 0;
				this.tigres[0]=new Tigre(800, 530);
				this.tigres[1]= new Tigre(1300, 530);
				cierra=false;
				level= level + 1;
			}
		}
		
		
		if(mono.getVidas()==0) {
			nivel=100;
			entorno.dibujarImagen(GameOver, 400, 300, anguloFondo, 0.5);
			if(HighScore < puntos) {
			HighScore = puntos;
			}
			this.musicafondo=false;
			ReproducirSonido("src/lose.wav/", cierra );
			cierra=true;
			if(entorno.sePresiono(entorno.TECLA_ENTER)) {
				cierra=false;
				
			}
			
			
			
			
			if(entorno.sePresiono(entorno.TECLA_ENTER)) {
				mono.setVidas(5);
				this.puntos=0;
				this.tigres[0]=new Tigre(1300, 530);;
				this.tigres[1]=new Tigre(800, 530);	
				this.aguila= new Aguila(800,0);
				level= 1;
			}
		}
		
	
		if(mono.getVidas() > 0 && puntos < nivel && jugar > 0) {
			if(HighScore >= nivel) {
				nivel = nivel + 200;
			}
			entorno.dibujarImagen(imgFondo, 400, 300, anguloFondo, 0.5);
			if(mono.getY() < 300) {
				mono.gravedad();
			}
			this.musicafondo=true;
			if (entorno.sePresiono(entorno.TECLA_ARRIBA)) {
				mono.setDebeSubir(true);
			}
			if (mono.isDebeSubir() == true) {

				if (mono.getY() > 300 && mono.salto == false) { // si el mono no salto y el valor de es menor la distancia
					mono.moverArriba(); 
					
					
				}
			}

			if (mono.getY() <= 300 || mono.salto == true) {
				
				mono.saltando();
				mono.saltando=true;

				if (mono.salto == true && (mono.getY() >= 300)) {
					mono.gravedad();
					bajarderama=false;
					if (mono.getY() == 530) {
						mono.sumaPunto=true;
						mono.salto = false;
						mono.saltando=false;
						
						mono.debeSubir = false;
					}
				}
			}
			

			
			for (int i = 0; i < arboles.length; i++) {
				if (arboles[i] != null) {
					arboles[i].moverIzquierda();
					arboles[i].dibujarse(entorno);
					if(mono.getY() <= arbol.getY()+10) {
						if (colision(mono.getX(), mono.getY()+(mono.getY()*0.1), arboles[i].rama.getX(), arboles[i].rama.getY(), 90)) {
							if(mono.sumaPunto==true) {
								this.puntos+=5;
								mono.sumaPunto=false;
								}
							
							
							mono.moverAbajoHasta(arboles[i].rama.getY() - (arboles[i].rama.getY() * 0.1));
							mono.saltando=false;
							if(entorno.sePresiono(entorno.TECLA_ARRIBA)) {
								
								
								mono.salto=false;
								}
							if(mono.salto==false) {
								mono.moverArriba();
								
							}
							}
					
					}
					if (mono.getY() >= arbol.getY()+10) {
						if (colision(mono.getX(), mono.getY()+(mono.getY()*0.1), arboles[i].rama.getX(), arboles[i].rama.getY(), 90)){
							bajarderama=true;
						}
					} 
						
						if (bajarderama == true) {
							mono.salto = true;
							mono.gravedad();
						}
				}

			
			
			}

			///
	
			//tigres	
			
			for (int i =0;i<tigres.length;i++) {
				if (tigres[i]!=null ) {
			
				if(colision(tigres[i].getX(), tigres[i].getY(), piedra.getX(), piedra.getY(), 40)) {
					tigres[i]=null;
					puntos+= 2;
					this.piedra	= new Piedra(-200,mono.getY());
					if(mono.getVidas() > 0) {
						ReproducirSonido("src/roar.wav/",cierra);
					}
					if (this.tigres[i]==null) {
						 tigres[i]=new Tigre((int)(Math.random() *((1300-1200)+1)) +1200, 530);
						
					}
					}
					if(colision(tigres[i].getX(), tigres[i].getY(), mono.getX(), mono.getY(), 80)) {
					
					tigres[i]=null;
					mono.setVidas(mono.getVidas() -1) ;
					puntos-= 2;
					if(mono.getVidas() > 0) {
						ReproducirSonido("src/roar.wav/",cierra);
						
					}
					if (this.tigres[i]==null) {
						 tigres[i]=new Tigre((int)(Math.random() *((1300-1200)+1)) +1200, 530);
						
					}
				}
				}
				
			
				
			
				}
			if (tigres[0]!=null) {
				tigres[0].moverIzquierda(4);
				tigres[0].dibujarse(entorno);
				}
			
			if (tigres[1]!=null) {
				tigres[1].moverIzquierda(4);
				tigres[1].dibujarse(entorno);
				}
			if (colision(tigres[0].getX(), tigres[0].getY(), tigres[1].getX(), tigres[1].getY(), 150)) {
				tigres[1].moverIzquierda(2);
			}
			
			
			//tigres
			
			
			//
			if (aguila !=null) {
				if(aguila.getY() > 700) {
					aguila=null;
					puntos+=1;
				}
			aguila.dibujarse(entorno);
			aguila.moverIzquierda();
			if(colision(aguila.getX(), aguila.getY(), mono.getX(), mono.getY(), 60)) {
				aguila=null;
				mono.setVidas(mono.getVidas() -1);
				if(mono.getVidas() > 0) {
					ReproducirSonido("src/aguila.wav/",cierra);
				}
			}
			if(aguila==null) {
				
					aguila= new Aguila(800,0);
				
			}
			if(colision(aguila.getX(), aguila.getY(), piedra.getX(), piedra.getY(), 40)) {
				aguila=null;
				puntos+= 13;
				this.piedra	= new Piedra(-200,mono.getY());
				if(mono.getVidas() > 0) {
					ReproducirSonido("src/aguila.wav/",cierra);
				}
			}
			if(aguila==null) {
				aguila= new Aguila(800,0);
			
		}
			}
			
			
			
			
			
			
			serpiente.dibujarse(entorno);
			serpiente.moverIzquierda();
			
			if(colision(serpiente.getX(), serpiente.getY(), mono.getX(), mono.getY(), 60)) {
				
				mono.setVidas(mono.getVidas() -1) ;
				serpiente=null;
				if(mono.getVidas() > 0) {
					ReproducirSonido("src/snake.wav/",cierra);
				}
				if(serpiente==null) {
					serpiente= new Serpiente(arboles[(int) (Math.random() * arboles.length)].rama.getX(),arboles[(int) (Math.random() * arboles.length)].rama.getY()-(arboles[(int) (Math.random() * arboles.length)].rama.getY()*0.1));
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					if (serpiente.getX()<800) {
						serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
					}
					
				}
			}
			if(colision(serpiente.getX(), serpiente.getY(), piedra.getX(), piedra.getY(), 60)) {
				serpiente=null;
				puntos+= 2;
				this.piedra	= new Piedra(-200,mono.getY());
				if(mono.getVidas() > 0) {
					ReproducirSonido("src/snake.wav/",cierra);
				}
				if(serpiente==null) {
					serpiente= new Serpiente(arboles[(int) (Math.random() * arboles.length)].rama.getX(),arboles[(int) (Math.random() * arboles.length)].rama.getY()-(arboles[(int) (Math.random() * arboles.length)].rama.getY()*0.1));
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						if (serpiente.getX()<800) {
							serpiente.setX(arboles[(int) (Math.random() * arboles.length)].rama.getX());
						}
						
					}
				
               
				}
			
			
		
	
		

		mono.dibujarse(entorno);
		entorno.cambiarFont("Franchise", 24, Color.black);
		entorno.escribirTexto("Vidas: " + mono.getVidas(), 650, 50);
		entorno.escribirTexto("Puntos: " + puntos, 50, 50);
		entorno.escribirTexto("HighScore: " + HighScore, 50, 100);
		entorno.escribirTexto("Nivel:" + level, 360, 50);
		



	if(entorno.sePresiono(entorno.TECLA_ESPACIO) && piedra.getX() == -200 ) {
		this.piedra	= new Piedra(115,mono.getY());
		
	}
	
		if(entorno.sePresiono(entorno.TECLA_ESPACIO)) {
			piedra.dibujar2(entorno); 
			piedra.seMueve();
		}
	
		if(this.piedra != null) {
			if(piedra.getX() >= 900) {
				this.piedra=null;
			}

				if (piedra.seMueve && piedra.getX() < 900) {
				piedra.moverDerecha();
				piedra.dibujar2(entorno);

			}
		
			if(piedra.getX() >= 900) {
				
				this.piedra	= new Piedra(-200,-123234);
			}
			
		}
	}
	}
	
		

	
	public boolean colision(double x1, double y1, double x2, double y2, double dist) {
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) < dist * dist;
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}

}

