package juego;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import entorno.Entorno;
import entorno.Herramientas;

public class Serpiente {


	// Variables de instancia
	private double x;
	private double y;
	private double angulo=0;
	private Image img2;
	private boolean ataca;

	
	
	
	public Serpiente(double b, double y) 
	{
		this.x = b;
		this.y = y;
	    ataca=false; 
		this.img2 = Herramientas.cargarImagen("ScentedNaughtyIcelandicsheepdog-size_restricted.gif");
			
	}
	
	public void dibujarse(Entorno entorno)
	{
		//entorno.dibujarTriangulo(this.x, this.y, 50, 30, this.angulo, Color.yellow);
	
		
			entorno.dibujarImagen(this.img2, this.x, this.y, this.angulo, 0.3);
			
		//	entorno.dibujarRectangulo(this.x, this.y, 60, 10, this.angulo, Color.yellow);
			
		
	
	}

	
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void moverIzquierda() {
		this.x -= Math.cos(-this.angulo)*3;
		
		if(this.x > 1700) {
			this.x=-100;
		}
		if(this.x < -100) {
			this.x=1700;
		}
	}
		

	

	public void quieto() {
		// TODO Auto-generated method stub
		this.ataca=true;
		}

	public void atacando() {
		// TODO Auto-generated method stub
		this.ataca=false;
		
	}
}





