package juego;



			
			import java.awt.Image;

			import entorno.Entorno;
			import entorno.Herramientas;

			public class Mono 
			{
				// Variables de instancia
				private double x;
				


				private double y;
				private	double angulo;
				private	Image img1;
				private Image img2;
				boolean salto;
				boolean saltando;
				boolean debeSubir;
				private	int suelo;
				boolean sumaPunto = true;
				private	int Vidas= 5;
				private	Piedra piedra;
				
				
				public Mono(int x, int y) 
				{
					this.x=x;
					this.suelo=x;
					this.y = y;
				    salto=false; 
				    saltando=false;
					this.img1 = Herramientas.cargarImagen("output-onlinegiftools.gif");
					this.img2 = Herramientas.cargarImagen("descarga.png");
				}
				
				public void dibujarse(Entorno entorno){
					if (saltando)
						entorno.dibujarImagen(this.img2, this.x, this.y, this.angulo, 0.5);
					else
						entorno.dibujarImagen(this.img1, this.x, this.y, this.angulo, 0.5);
				}
				
				public void moverArriba() {
					this.y -= Math.cos(0)*5;
					
					
				}
				
				
				 public void gravedad() {
					 this.y += Math.cos(0)*4;
						if(this.y >= 530) {
							this.y=530;
						}
					
				 }
				 
				 public void moverAbajoHasta(double d) {
						this.y += Math.cos(0)*5;
						if(this.y >= d) {
							this.y=d;}
							
				 }
				
				public void saltando() {
					if(this.y < 530) {
						this.salto = true;
					}
				}
				
				
				public boolean debeBajar() {
					if(this.y < 600) {
						return true;
					}
					else {
						return false;
					}
				}

				
			

			public double getX() {
				return x;
			}

			public void setX(double x) {
				this.x = x;
			}

			public double getY() {
				return y;
			}

			public void setY(double y) {
				this.y = y;
			}

			public double getAngulo() {
				return angulo;
			}

			public void setAngulo(double angulo) {
				this.angulo = angulo;
			}

			public Image getImg1() {
				return img1;
			}

			public void setImg1(Image img1) {
				this.img1 = img1;
			}

			public Image getImg2() {
				return img2;
			}

			public void setImg2(Image img2) {
				this.img2 = img2;
			}

			public boolean isSalto() {
				return salto;
			}

			public void setSalto(boolean salto) {
				this.salto = salto;
			}

			public boolean isSaltando() {
				return saltando;
			}

			public void setSaltando(boolean saltando) {
				this.saltando = saltando;
			}

			public boolean isDebeSubir() {
				return debeSubir;
			}

			public void setDebeSubir(boolean debeSubir) {
				this.debeSubir = debeSubir;
			}

			public int getSuelo() {
				return suelo;
			}

			public void setSuelo(int suelo) {
				this.suelo = suelo;
			}

			public boolean isSumaPunto() {
				return sumaPunto;
			}

			public void setSumaPunto(boolean sumaPunto) {
				this.sumaPunto = sumaPunto;
			}

			public int getVidas() {
				return Vidas;
			}

			public void setVidas(int vidas) {
				Vidas = vidas;
			}

			public Piedra getPiedra() {
				return piedra;
			}

			public void setPiedra(Piedra piedra) {
				this.piedra = piedra;
			}


		}


