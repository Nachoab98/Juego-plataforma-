package juego;


import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Piedra {
	private double x;
	private double y;
	boolean seMueve= false;
	Image img1;
	
	public Piedra(double x, double y) {
		this.x=x;
		this.y=y;
		this.img1 = Herramientas.cargarImagen("piedra.png");
	}
	public void dibujar2(Entorno entorno) {
		entorno.dibujarImagen(img1, x, y, 0, 0.05);
		//entorno.dibujarRectangulo(x, y, 5, 5, 0, Color.RED);
}
	
	public void seMueve() {
		this.seMueve=true;

	}
	
	public void moverDerecha() {
		this.x += 7;        
    }
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	
	
	
}