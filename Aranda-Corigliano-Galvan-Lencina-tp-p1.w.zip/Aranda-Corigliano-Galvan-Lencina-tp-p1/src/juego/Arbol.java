package juego;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import entorno.Entorno;
import entorno.Herramientas;

public class Arbol
{
	// Variables de instancia
	private double x;
	private double y;
	private double angulo=0;
	private Image img2;
	private boolean motor;
	
	Rama rama;
	
	
	
	public Arbol(int x, int y,Image a) 
	{
		this.x = x;
		this.y = y;
	    motor=false; 
		this.img2 = a;
		this.rama= new Rama(this.x, this.y+10);
	
		
	}
	
	
	
	public void dibujarse(Entorno entorno)
	{
		//entorno.dibujarTriangulo(this.x, this.y, 50, 30, this.angulo, Color.yellow);
	
		
			entorno.dibujarImagen(this.img2, this.x, this.y, this.angulo, 1);
			this.rama.dibujarse(entorno);
			
			this.rama.moverIzquierda();
		//	entorno.dibujarRectangulo(this.x, this.y, 60, 10, this.angulo, Color.yellow);
			
		
	
	}

	
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void moverIzquierda() {
		this.x -= Math.cos(-this.angulo)*3;
		
		if(this.x > 1700) {
			this.x=-100;
		}
		if(this.x < -100) {
			this.x=1700;
		}
	}
		

	

	public void prenderMotor() {
		// TODO Auto-generated method stub
		this.motor=true;
		}

	public void apagarMotor() {
		// TODO Auto-generated method stub
		this.motor=false;
		
	}
}













