package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Aguila {
	private double x;
	private double y;
	private double angulo=0;
	private Image img2;

	
	public Aguila(double b, double y) 
	{
		this.x = b;
		this.y = y;
		this.img2= Herramientas.cargarImagen("aguila.gif");
			
	}
	public void dibujarse(Entorno entorno)
	{
		//entorno.dibujarTriangulo(this.x, this.y, 50, 30, this.angulo, Color.yellow);
	
		
			entorno.dibujarImagen(this.img2, this.x, this.y, this.angulo, 0.5);
			
		//	entorno.dibujarRectangulo(this.x, this.y, 60, 10, this.angulo, Color.yellow);
			
		
	
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void moverIzquierda() {
		this.x -= Math.cos(0)*2;
		this.y += Math.cos(0.8)*2;

		if(this.y > 700) {
			this.y=0;
			this.x=800;
		}
		
		
		}
}