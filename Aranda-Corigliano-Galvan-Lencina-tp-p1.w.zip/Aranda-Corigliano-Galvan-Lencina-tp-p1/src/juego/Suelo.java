package juego;

import java.awt.Color;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;

import entorno.Entorno;
import entorno.Herramientas;

public class Suelo {
	
	double x;
	double y;
	double ancho;
	double alto;
	
	public Suelo (double x,double y,double ancho,double alto) {
		Shape rect = new Rectangle((int) x, (int) y, (int) ancho, (int) alto);
		this.x = x;
		this.y = y;
		this.alto = alto;
		this.ancho = ancho;
	}
}
