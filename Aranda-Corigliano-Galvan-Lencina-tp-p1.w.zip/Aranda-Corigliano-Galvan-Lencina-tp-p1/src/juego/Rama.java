package juego;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import entorno.Entorno;
import entorno.Herramientas;

public class Rama
{
	// Variables de instancia
	private double x;
	private double y;
	private double angulo=0;
	private Image img;
	
	
	
	
	
	public Rama(double x, double y) 
	{
		this.x = x;
		this.y = y;
		this.img=Herramientas.cargarImagen("rama.png");
	
		
	}
	
	public void dibujarse(Entorno entorno)
	{
		//entorno.dibujarTriangulo(this.x, this.y, 50, 30, this.angulo, Color.yellow);
	
		
			entorno.dibujarImagen(this.img, this.x, this.y, this.angulo, 0.4);
			
			
		
	
	}

	
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void moverIzquierda() {
		this.x -= Math.cos(-this.angulo)*3;
		
		if(this.x > 1700) {
			this.x=-100;
		}
		if(this.x < -100) {
			this.x=1700;
		}
	}
		

	

	
}













